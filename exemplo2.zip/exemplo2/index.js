const axios = require('axios');
const verificador=0;
axios.get('https://api.tvmaze.com/shows')
 .then(response => {
 dados=response.data;
 for (let i = 0; i < dados.length; i++) {
    console.log("ID:"+dados[i].id+" Nome: "+dados[i].name);
 }
 for (let i = 0; i < dados.length; i++) {
    if (dados[i].id==process.argv[2]){
        console.log(dados[i]);
        verificador=verificador+1;
    }
}
if(verificador==0){
        console.log("\nSérie não encontrada");
    }
 })
 .catch(error => {
 console.error('Erro:', error);
 });
